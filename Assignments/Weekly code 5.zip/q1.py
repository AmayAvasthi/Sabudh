{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "2dabbf55-53d9-4f87-bba1-254a46f9cfb2",
   "metadata": {},
   "outputs": [],
   "source": [
    "def gcd(a,b):\n",
    "    c = min(a,b)\n",
    "    ls = []\n",
    "\n",
    "    for i in range (1 , c+1):\n",
    "        if a%i == 0 and b%i == 0:\n",
    "            ls.append(i)\n",
    "\n",
    "\n",
    "    d = max(ls)\n",
    "\n",
    "    print(f\"The highest common divisor for {a} and {b} is {d}\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "9460fe85-653a-47c5-a486-77e6acc8e4f7",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "The highest common divisor for 12 and 14 is 2\n",
      "The highest common divisor for 32 and 36 is 4\n"
     ]
    }
   ],
   "source": [
    "gcd(12,14)\n",
    "gcd(32,36)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
