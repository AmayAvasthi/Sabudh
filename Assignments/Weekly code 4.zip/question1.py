{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "57d90ea1-8b1e-412e-97d9-73cd92992d7e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "4.0\n"
     ]
    }
   ],
   "source": [
    "def evaluate_postfix(expression):\n",
    "    stack = []\n",
    "\n",
    "    operators = set(['+', '-', '*', '/', '^'])\n",
    "\n",
    "    for char in expression:\n",
    "        if char not in operators:\n",
    "            stack.append(int(char))\n",
    "        else:\n",
    "            operand2 = stack.pop()\n",
    "            operand1 = stack.pop()\n",
    "\n",
    "            if char == '+':\n",
    "                result = operand1 + operand2\n",
    "            elif char == '-':\n",
    "                result = operand1 - operand2\n",
    "            elif char == '*':\n",
    "                result = operand1 * operand2\n",
    "            elif char == '/':\n",
    "                result = operand1 / operand2\n",
    "            elif char == '^':\n",
    "                result = operand1 ** operand2\n",
    "\n",
    "            stack.append(result)\n",
    "\n",
    "    return stack[0]\n",
    "\n",
    "postfix_expression = \"82/\"\n",
    "result = evaluate_postfix(postfix_expression)\n",
    "print(result) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c7dcdd09-da51-4376-81a2-f88c6c27ecaf",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
