{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 10,
   "id": "57d90ea1-8b1e-412e-97d9-73cd92992d7e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "True\n"
     ]
    }
   ],
   "source": [
    "def process_string(s):\n",
    "    stack = []\n",
    "    for char in s:\n",
    "        if char == '#':\n",
    "            if stack:\n",
    "                stack.pop()\n",
    "        else:\n",
    "            stack.append(char)\n",
    "    return ''.join(stack)\n",
    "\n",
    "def backspaceCompare(S, T):\n",
    "    return process_string(S) == process_string(T)\n",
    "\n",
    "input1 = \"ab#c\"\n",
    "input2 = \"ad#c\"\n",
    "output = backspaceCompare(input1, input2)\n",
    "print(output)  \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c7dcdd09-da51-4376-81a2-f88c6c27ecaf",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
