{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "57d90ea1-8b1e-412e-97d9-73cd92992d7e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "[-1, 3, -1]\n"
     ]
    }
   ],
   "source": [
    "def nextGreaterElement(nums1, nums2):\n",
    "    next_greater = {}\n",
    "    stack = []\n",
    "\n",
    "    for num in nums2:\n",
    "        while stack and num > stack[-1]:\n",
    "            next_greater[stack.pop()] = num\n",
    "        stack.append(num)\n",
    "\n",
    "    result = [-1] * len(nums1)\n",
    "\n",
    "    for i in range(len(nums1)):\n",
    "        if nums1[i] in next_greater:\n",
    "            result[i] = next_greater[nums1[i]]\n",
    "\n",
    "    return result\n",
    "\n",
    "nums1 = [4, 1, 2]\n",
    "nums2 = [1, 3, 4, 2]\n",
    "output = nextGreaterElement(nums1, nums2)\n",
    "print(output) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c7dcdd09-da51-4376-81a2-f88c6c27ecaf",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
