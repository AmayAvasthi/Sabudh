{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 12,
   "id": "57d90ea1-8b1e-412e-97d9-73cd92992d7e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "True\n"
     ]
    }
   ],
   "source": [
    "def isValid(s):\n",
    "    stack = []\n",
    "    bracket_map = {')': '(', '}': '{', ']': '['}\n",
    "\n",
    "    for char in s:\n",
    "        if char in bracket_map:\n",
    "            top_element = stack.pop() if stack else '#'\n",
    "            if bracket_map[char] != top_element:\n",
    "                return False\n",
    "        else:\n",
    "            stack.append(char)\n",
    "\n",
    "    return not stack\n",
    "\n",
    "input_string = \"()\"\n",
    "output = isValid(input_string)\n",
    "print(output) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c7dcdd09-da51-4376-81a2-f88c6c27ecaf",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
