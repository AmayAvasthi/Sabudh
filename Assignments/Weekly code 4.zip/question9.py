{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 18,
   "id": "57d90ea1-8b1e-412e-97d9-73cd92992d7e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "['((()))', '(()())', '(())()', '()(())', '()()()']\n"
     ]
    }
   ],
   "source": [
    "def generateParenthesis(n):\n",
    "    def backtrack(combination, open_count, close_count):\n",
    "        if len(combination) == 2 * n:\n",
    "            result.append(combination)\n",
    "            return\n",
    "        if open_count < n:\n",
    "            backtrack(combination + \"(\", open_count + 1, close_count)\n",
    "        if close_count < open_count:\n",
    "            backtrack(combination + \")\", open_count, close_count + 1)\n",
    "\n",
    "    result = []\n",
    "    backtrack(\"\", 0, 0)\n",
    "    return result\n",
    "\n",
    "n = 3\n",
    "output = generateParenthesis(n)\n",
    "print(output) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c7dcdd09-da51-4376-81a2-f88c6c27ecaf",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
