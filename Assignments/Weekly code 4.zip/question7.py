{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 14,
   "id": "57d90ea1-8b1e-412e-97d9-73cd92992d7e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "1219\n"
     ]
    }
   ],
   "source": [
    "def removeKdigits(num, k):\n",
    "    stack = []\n",
    "\n",
    "    for digit in num:\n",
    "        while k > 0 and stack and stack[-1] > digit:\n",
    "            stack.pop()\n",
    "            k -= 1\n",
    "        stack.append(digit)\n",
    "\n",
    "    while k > 0:\n",
    "        stack.pop()\n",
    "        k -= 1\n",
    "\n",
    "    result = ''.join(stack)\n",
    "\n",
    "    result = result.lstrip('0')\n",
    "\n",
    "    if not result:\n",
    "        return '0'\n",
    "\n",
    "    return result\n",
    "\n",
    "input_num = \"1432219\"\n",
    "k = 3\n",
    "output = removeKdigits(input_num, k)\n",
    "print(output)  \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c7dcdd09-da51-4376-81a2-f88c6c27ecaf",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
