{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 16,
   "id": "57d90ea1-8b1e-412e-97d9-73cd92992d7e",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "aaabcbc\n"
     ]
    }
   ],
   "source": [
    "def decodeString(s):\n",
    "    stack = []\n",
    "    current_num = 0\n",
    "    current_str = \"\"\n",
    "\n",
    "    for char in s:\n",
    "        if char.isdigit():\n",
    "            current_num = current_num * 10 + int(char)\n",
    "        elif char == '[':\n",
    "            stack.append((current_num, current_str))\n",
    "            current_num = 0\n",
    "            current_str = \"\"\n",
    "        elif char == ']':\n",
    "            num, prev_str = stack.pop()\n",
    "            current_str = prev_str + num * current_str\n",
    "        else:\n",
    "            current_str += char\n",
    "\n",
    "    return current_str\n",
    "\n",
    "input_str = \"3[a]2[bc]\"\n",
    "output = decodeString(input_str)\n",
    "print(output) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "c7dcdd09-da51-4376-81a2-f88c6c27ecaf",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
