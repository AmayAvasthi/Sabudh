#!/usr/bin/env python
# coding: utf-8

# In[76]:


def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

# Test Case 1
input1 = 4
output1 = factorial(input1)
print("Output for Test Case 1:", output1)

# Test Case 2
input2 = 2
output2 = factorial(input2)
print("Output for Test Case 2:", output2)


# In[ ]:




