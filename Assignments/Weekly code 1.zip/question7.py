#!/usr/bin/env python
# coding: utf-8

# In[73]:


input_list=[10,20,30,40,50,60,70,80,90,100]
pp=[]
for i in range(len(input_list)):
    if(i%2!=0):
        pp.append(input_list[i])
print(pp)


# In[74]:


input_list=[23, 46, 69, 92, 115]
pp=[]
for i in range(len(input_list)):
    if(i%2!=0):
        pp.append(input_list[i])
print(pp)


# In[ ]:




