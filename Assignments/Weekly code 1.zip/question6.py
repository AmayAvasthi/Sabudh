#!/usr/bin/env python
# coding: utf-8

# In[66]:


number=745633
list_of_digits=list(map(int,str(number)))
a=list_of_digits
a[::-1]


# In[67]:


number=65346
list_of_digits=list(map(int,str(number)))
a=list_of_digits
a[::-1]


# In[ ]:




