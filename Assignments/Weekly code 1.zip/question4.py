#!/usr/bin/env python
# coding: utf-8

# In[62]:


number=75869
list_of_digits=list(map(int,str(number)))
count=0
for i in list_of_digits:
    count+=1
print(count)


# In[63]:


number=654
list_of_digits=list(map(int,str(number)))
count=0
for i in list_of_digits:
    count+=1
print(count)


# In[ ]:




