#!/usr/bin/env python
# coding: utf-8

# In[47]:


def count_vowels_and_consonants(word):
    vowels = "aeiouAEIOU"
    vowel_count = 0
    consonant_count = 0
    
    for char in word:
        if char in vowels:
            vowel_count += 1
        elif char.isalpha():
            consonant_count += 1
            
    return vowel_count, consonant_count

# Test Case 1
input_word1 = "pythonlobby"
vowels1, consonants1 = count_vowels_and_consonants(input_word1)
print("Output for Test Case 1:")
print("Vowels:", vowels1)
print("Consonants:", consonants1)

# Test Case 2
input_word2 = "sabudhfoundation"
vowels2, consonants2 = count_vowels_and_consonants(input_word2)
print("Output for Test Case 2:")
print("Vowels:", vowels2)
print("Consonants:", consonants2)


# In[ ]:




