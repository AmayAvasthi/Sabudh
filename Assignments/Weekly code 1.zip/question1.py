#!/usr/bin/env python
# coding: utf-8

# In[48]:


N=int(input("Input: "))
output=[i**2 for i in range(N)]
print("Output:",output)


# In[49]:


N=int(input("Input: "))
output=[i**2 for i in range(N)]
print("Output:",output)


# In[ ]:




