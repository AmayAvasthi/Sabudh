#!/usr/bin/env python
# coding: utf-8

# In[53]:


def remove_duplicates(input_str):
    seen = set() 
    output_str = "" 
    for char in input_str: 
        if char not in seen: 
            seen.add(char) 
            output_str += char 
    return output_str
# Test Case 1
input_str1 = "abaabbbacd"
output_str1 = remove_duplicates(input_str1)
print("Output for Test Case 1:", output_str1)
# Test Case 2
input_str2 = "ddeefggh"
output_str2 = remove_duplicates(input_str2)
print("Output for Test Case 2:", output_str2)


# In[ ]:




