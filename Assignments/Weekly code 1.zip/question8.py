#!/usr/bin/env python
# coding: utf-8

# In[75]:


def find_median(a, b, c):
    # Sort the values
    sorted_values = sorted([a, b, c])
    
    # The median will be the middle value
    median = sorted_values[1]
    
    return median

# Test Case 1
first_num1 = int(input("Input first number: "))
second_num1 = int(input("Input second number: "))
third_num1 = int(input("Input third number: "))
output1 = find_median(first_num1, second_num1, third_num1)
print("Output for Test Case 1:", output1)

# Test Case 2
first_num2 = int(input("Input first number: "))
second_num2 = int(input("Input second number: "))
third_num2 = int(input("Input third number: "))
output2 = find_median(first_num2, second_num2, third_num2)
print("Output for Test Case 2:", output2)


# In[ ]:




