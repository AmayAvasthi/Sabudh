#!/usr/bin/env python
# coding: utf-8

# In[60]:


def filter_numbers(input_list):
    output_list = []

    for num in input_list:
        if num % 5 == 0:
            if num > 500:
                break
            elif num > 150:
                continue
            else:
                output_list.append(num)

    return output_list

# Test Case 1
input_list1 = [12, 75, 150, 180, 145, 525, 50]
output_list1 = filter_numbers(input_list1)
print("Output for Test Case 1:", output_list1)

# Test Case 2
input_list2 = [14, 85, 625, 75]
output_list2 = filter_numbers(input_list2)
print("Output for Test Case 2:", output_list2)


# In[ ]:




