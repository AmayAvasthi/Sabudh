#!/usr/bin/env python
# coding: utf-8

# In[64]:


def calculate_series_sum(n):
    total_sum = 0
    term = 2
    current_term = 0

    for i in range(n):
        current_term = current_term * 10 + term
        total_sum += current_term

    return total_sum

# Test Case 1
input_n1 = 5
output1 = calculate_series_sum(input_n1)
print("Output for Test Case 1:", output1)

# Test Case 2
input_n2 = 6
output2 = calculate_series_sum(input_n2)
print("Output for Test Case 2:", output2)


# In[ ]:




