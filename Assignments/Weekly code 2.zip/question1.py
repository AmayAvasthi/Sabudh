{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "[-12, -6, -13, -5, -3, -7, 5, 6, 11]\n",
      "[-12, -3, -7, -5, 6, 13, 5, 11, 8]\n"
     ]
    }
   ],
   "source": [
    "def rearrange_array(arr):\n",
    "    left = 0\n",
    "    right = len(arr) - 1\n",
    "\n",
    "    while left <= right:\n",
    "        while left <= right and arr[left] < 0:\n",
    "            left += 1\n",
    "\n",
    "        while left <= right and arr[right] >= 0:\n",
    "            right -= 1\n",
    "\n",
    "        if left <= right:\n",
    "            arr[left], arr[right] = arr[right], arr[left]\n",
    "            left += 1\n",
    "            right -= 1\n",
    "\n",
    "    return arr\n",
    "\n",
    "# Test case\n",
    "arr1 = [-12, 11, -13, -5, 6, -7, 5, -3, -6]\n",
    "arr2 = [-12, 11, 13, -5, 6, -7, 5, -3, 8]\n",
    "result = rearrange_array(arr1)\n",
    "result1 = rearrange_array(arr2)\n",
    "print(result)\n",
    "print(result1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "0a73a7ae-3c0d-453e-a39f-9fbedc16e96b",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
