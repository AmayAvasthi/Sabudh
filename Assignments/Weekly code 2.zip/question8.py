{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 23,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "The triplet having the maximum product is (-8, -4, 9)\n",
      "The triplet having the maximum product is (7, 5, 2)\n"
     ]
    }
   ],
   "source": [
    "def max_triplet_product(arr):\n",
    "    if len(arr) < 3:\n",
    "        return \"No triplet exists\"\n",
    "\n",
    "    max1, max2, max3 = float('-inf'), float('-inf'), float('-inf')\n",
    "    min1, min2 = float('inf'), float('inf')\n",
    "\n",
    "    for num in arr:\n",
    "        if num > max1:\n",
    "            max3, max2, max1 = max2, max1, num\n",
    "        elif num > max2:\n",
    "            max3, max2 = max2, num\n",
    "        elif num > max3:\n",
    "            max3 = num\n",
    "\n",
    "        if num < min1:\n",
    "            min2, min1 = min1, num\n",
    "        elif num < min2:\n",
    "            min2 = num\n",
    "\n",
    "    if max1 * max2 * max3 > min1 * min2 * max1:\n",
    "        return f\"The triplet having the maximum product is ({max1}, {max2}, {max3})\"\n",
    "    else:\n",
    "        return f\"The triplet having the maximum product is ({min1}, {min2}, {max1})\"\n",
    "\n",
    "# Test case 1\n",
    "arr1 = [-4, 1, -8, 9, 6]\n",
    "result1 = max_triplet_product(arr1)\n",
    "print(result1) \n",
    "\n",
    "# Test case 2\n",
    "arr2 = [1, 7, 2, -2, 5]\n",
    "result2 = max_triplet_product(arr2)\n",
    "print(result2)  \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "61f73312-9add-41f4-b2be-c52cb06c4d32",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
