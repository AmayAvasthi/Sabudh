{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 27,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "The trapped water is 2\n",
      "The trapped water is 6\n"
     ]
    }
   ],
   "source": [
    "def trap(arr):\n",
    "    if not arr:\n",
    "        return 0\n",
    "\n",
    "    n = len(arr)\n",
    "    left_max = [0] * n\n",
    "    right_max = [0] * n\n",
    "\n",
    "    left_max[0] = arr[0]\n",
    "    for i in range(1, n):\n",
    "        left_max[i] = max(left_max[i - 1], arr[i])\n",
    "\n",
    "    right_max[n - 1] = arr[n - 1]\n",
    "    for i in range(n - 2, -1, -1):\n",
    "        right_max[i] = max(right_max[i + 1], arr[i])\n",
    "\n",
    "    trapped_water = 0\n",
    "    for i in range(n):\n",
    "        trapped_water += min(left_max[i], right_max[i]) - arr[i]\n",
    "\n",
    "    return trapped_water\n",
    "\n",
    "# Test case 1\n",
    "arr1 = [2, 0, 2]\n",
    "result1 = trap(arr1)\n",
    "print(\"The trapped water is\", result1) \n",
    "\n",
    "# Test case 2\n",
    "arr2 = [0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]\n",
    "result2 = trap(arr2)\n",
    "print(\"The trapped water is\", result2)  \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "61f73312-9add-41f4-b2be-c52cb06c4d32",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
