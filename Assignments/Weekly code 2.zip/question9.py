{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 25,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "The median is 3\n",
      "The median is 11.0\n"
     ]
    }
   ],
   "source": [
    "def findMedianSortedArrays(a, b):\n",
    "    if len(a) > len(b):\n",
    "        a, b = b, a  \n",
    "\n",
    "    m, n = len(a), len(b)\n",
    "    imin, imax, half_len = 0, m, (m + n + 1) // 2\n",
    "\n",
    "    while imin <= imax:\n",
    "        i = (imin + imax) // 2\n",
    "        j = half_len - i\n",
    "\n",
    "        if i < m and b[j - 1] > a[i]:\n",
    "            imin = i + 1 \n",
    "        elif i > 0 and a[i - 1] > b[j]:\n",
    "            imax = i - 1  \n",
    "        else:\n",
    "            if i == 0: max_of_left = b[j - 1]\n",
    "            elif j == 0: max_of_left = a[i - 1]\n",
    "            else: max_of_left = max(a[i - 1], b[j - 1])\n",
    "\n",
    "            if (m + n) % 2 == 1:\n",
    "                return max_of_left\n",
    "\n",
    "            if i == m: min_of_right = b[j]\n",
    "            elif j == n: min_of_right = a[i]\n",
    "            else: min_of_right = min(a[i], b[j])\n",
    "\n",
    "            return (max_of_left + min_of_right) / 2.0\n",
    "\n",
    "# Test case 1\n",
    "a1 = [-5, 3, 6, 12, 15]\n",
    "b1 = [-12, -10, -6, -3, 4, 10]\n",
    "result1 = findMedianSortedArrays(a1, b1)\n",
    "print(\"The median is\", result1) \n",
    "\n",
    "# Test case 2\n",
    "a2 = [2, 3, 5, 8]\n",
    "b2 = [10, 12, 14, 16, 18, 20]\n",
    "result2 = findMedianSortedArrays(a2, b2)\n",
    "print(\"The median is\", result2) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "61f73312-9add-41f4-b2be-c52cb06c4d32",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
