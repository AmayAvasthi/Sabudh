{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 14,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "wWW.gOoGLE.COM\n",
      "hOW aREE yOUU?\n"
     ]
    }
   ],
   "source": [
    "def swap_case(s):\n",
    "    return s.swapcase()\n",
    "\n",
    "# Test case 1\n",
    "input_str1 = \"Www.GoOgle.com\"\n",
    "output_str1 = swap_case(input_str1)\n",
    "print(output_str1)  \n",
    "\n",
    "# Test case 2\n",
    "input_str2 = \"How Aree Youu?\"\n",
    "output_str2 = swap_case(input_str2)\n",
    "print(output_str2) \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "61f73312-9add-41f4-b2be-c52cb06c4d32",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
