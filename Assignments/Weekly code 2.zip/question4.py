{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 12,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Minimum Difference is 2\n",
      "Minimum Difference is 6\n"
     ]
    }
   ],
   "source": [
    "def find_min_difference(arr, n, m):\n",
    "    if m == 0 or n == 0:\n",
    "        return 0\n",
    "\n",
    "    arr.sort()\n",
    "\n",
    "    min_diff = float('inf')\n",
    "    for i in range(n - m + 1):\n",
    "        diff = arr[i + m - 1] - arr[i]\n",
    "        if diff < min_diff:\n",
    "            min_diff = diff\n",
    "\n",
    "    return min_diff\n",
    "\n",
    "# Test case\n",
    "arr = [7, 3, 2, 4, 9, 12, 56]\n",
    "m = 3\n",
    "n = len(arr)\n",
    "result = find_min_difference(arr, n, m)\n",
    "print(\"Minimum Difference is\", result)  \n",
    "\n",
    "arr1 = [3, 4, 1, 9, 56, 7, 9, 12]\n",
    "m1 = 5\n",
    "n1 = len(arr1)\n",
    "result = find_min_difference(arr1, n1, m1)\n",
    "print(\"Minimum Difference is\", result)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "61f73312-9add-41f4-b2be-c52cb06c4d32",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
