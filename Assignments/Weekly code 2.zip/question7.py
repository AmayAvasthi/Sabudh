{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 22,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "[1, 9, 15, 2]\n",
      "[1, 4, 5, 6, 2, 3]\n"
     ]
    }
   ],
   "source": [
    "def shuffle_array(arr):\n",
    "    n = len(arr) // 2\n",
    "\n",
    "    for i in range(n):\n",
    "        j = i + n  \n",
    "        \n",
    "        \n",
    "        while j > i + 1:\n",
    "            arr[j], arr[j - 1] = arr[j - 1], arr[j]\n",
    "            j -= 1\n",
    "\n",
    "# Test case 1\n",
    "arr1 = [1, 2, 9, 15]\n",
    "shuffle_array(arr1)\n",
    "print(arr1) \n",
    "# Test case 2\n",
    "arr2 = [1, 2, 3, 4, 5, 6]\n",
    "shuffle_array(arr2)\n",
    "print(arr2)  "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "61f73312-9add-41f4-b2be-c52cb06c4d32",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
