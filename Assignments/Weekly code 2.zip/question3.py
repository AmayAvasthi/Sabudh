{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "2\n",
      "3\n"
     ]
    }
   ],
   "source": [
    "def count_pairs_with_sum(arr, target_sum):\n",
    "    num_pairs = 0\n",
    "    num_freq = {}  \n",
    "\n",
    "    for num in arr:\n",
    "        complement = target_sum - num\n",
    "        if complement in num_freq:\n",
    "            num_pairs += num_freq[complement]\n",
    "        if num in num_freq:\n",
    "            num_freq[num] += 1\n",
    "        else:\n",
    "            num_freq[num] = 1\n",
    "\n",
    "    return num_pairs\n",
    "\n",
    "arr1 = [1, 5, 7, -1]\n",
    "sum1 = 6\n",
    "result1 = count_pairs_with_sum(arr1, sum1)\n",
    "print(result1) \n",
    "\n",
    "arr2 = [1, 5, 7, -1, 5]\n",
    "sum2 = 6\n",
    "result2 = count_pairs_with_sum(arr2, sum2)\n",
    "print(result2) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "0a73a7ae-3c0d-453e-a39f-9fbedc16e96b",
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "97e11d4d-3894-43bb-9f57-453a9c2335fc",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
