{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 13,
   "id": "6197f8c1-5b71-4b93-926d-4562d3a04471",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "6\n",
      "8\n"
     ]
    }
   ],
   "source": [
    "def max_j_minus_i(arr):\n",
    "    n = len(arr)\n",
    "\n",
    "    left_min = [0] * n\n",
    "    left_min[0] = arr[0]\n",
    "    for i in range(1, n):\n",
    "        left_min[i] = min(left_min[i - 1], arr[i])\n",
    "\n",
    "    right_max = [0] * n\n",
    "    right_max[n - 1] = arr[n - 1]\n",
    "    for i in range(n - 2, -1, -1):\n",
    "        right_max[i] = max(right_max[i + 1], arr[i])\n",
    "\n",
    "    i, j, max_diff = 0, 0, -1\n",
    "\n",
    "    while j < n and i < n:\n",
    "        if right_max[j] > left_min[i]:\n",
    "            max_diff = max(max_diff, j - i)\n",
    "            j += 1\n",
    "        else:\n",
    "            i += 1\n",
    "\n",
    "    return max_diff\n",
    "\n",
    "# Test case 1\n",
    "arr1 = [34, 8, 10, 3, 2, 80, 30, 33, 1]\n",
    "result1 = max_j_minus_i(arr1)\n",
    "print(result1) \n",
    "\n",
    "# Test case 2\n",
    "arr2 = [9, 2, 3, 4, 5, 6, 7, 8, 18, 0]\n",
    "result2 = max_j_minus_i(arr2)\n",
    "print(result2)  \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "61f73312-9add-41f4-b2be-c52cb06c4d32",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
