#!/usr/bin/env python
# coding: utf-8

# In[8]:


get_ipython().system('pip install numpy')
get_ipython().system('pip install pandas')
get_ipython().system('pip install sklearn')
get_ipython().system('pip install matplotlib')
get_ipython().system('pip install -U scikit-learn')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split


# In[11]:


fp=pd.read_csv('C:\\Users\\Gurmukh Sran\\Desktop\\Sabudh Intership\\fp.csv')


# In[12]:


fp


# In[13]:


fp.info()


# In[14]:


fp.region.value_counts()


# In[15]:


fp['region']=fp['region'].fillna(2.0)


# In[16]:


fp.info()


# In[17]:


temp_data = fp.copy()


# In[18]:


def newPosCat(inputCat):

    if inputCat == 1:
        return('Attackers')
    elif inputCat == 2:
        return('Midfielders')
    elif inputCat == 3:
        return('Defenders')
    else:
        return('Goalkeeper')

temp_data['position_cat'] = temp_data['position_cat'].apply(newPosCat)


# In[19]:


def newRegion(inpregion):
    
    if inpregion == 1:
        return('England')
    elif inpregion == 2:
        return('EU')
    elif inpregion == 3:
        return('Americans')
    else:
        return('Rest of World')

temp_data['region'] = temp_data['region'].apply(newRegion)


# In[20]:


temp_data.head()


# In[21]:


temp_data[['age_cat','age']].corr()


# In[22]:


temp_data['age'].unique()


# In[23]:


def retrieveAgeCategories(temp_data):
    int_age_categories = sorted(temp_data['age_cat'].unique())
    age_categories = {}
    for i in int_age_categories:
        records = (temp_data[temp_data['age_cat'] == i])
        age_categories[i] = str(min(records['age'])) + "-" + str(max(records['age']))
    return age_categories

age_categories = retrieveAgeCategories(temp_data)
age_categories


# In[24]:


def age_cat_convert(inp_age_cat, age_categories):
    return age_categories[inp_age_cat]

temp_data['age_cat'] = temp_data['age_cat'].apply(age_cat_convert, args=(age_categories,))


# In[25]:


temp_data.head()


# In[26]:


temp_data['position'].unique()


# In[27]:


temp_data['club'].unique()


# In[28]:


temp_data['club_id'].unique()


# In[29]:


temp_data.drop(['name','club_id'], axis=1 , inplace=True)


# In[30]:


temp_data.head()


# In[31]:


temp_data['fpl_sel'] = temp_data['fpl_sel'].map(lambda x: str(x)[:-1]).astype('float')/100
temp_data.head()


# In[32]:


temp_data.describe()


# In[35]:


get_ipython().system('pip install seaborn')
import seaborn as sns
sns.distplot(temp_data['market_value'])


# In[37]:


corr = temp_data.corr()
corr


# In[38]:


corr['market_value'].sort_values()


# In[39]:


plt.figure(figsize=(20,10)) 
sns.boxplot(x = 'age_cat', y = "market_value", data = temp_data, order = list(age_categories.values()), palette='rainbow')


# In[40]:


plt.figure(figsize=(20, 10)) 
sns.boxplot(x = 'region', y = "market_value", hue = 'big_club', data = temp_data)


# In[41]:


plt.figure(figsize=(20, 10)) 
sns.boxplot(x = 'position_cat', y = "market_value", data = temp_data, palette='rainbow')


# In[42]:


sns.boxplot(x="big_club", y="market_value", data=temp_data)


# In[43]:


sns.boxplot(x="new_signing", y="market_value", data=temp_data)


# In[44]:


sns.boxplot(x="new_foreign", y="market_value", data=temp_data)


# In[45]:


sns.boxplot(x='region',y = "market_value", data=temp_data)


# In[46]:


plt.figure(figsize=(20, 10)) 
sns.barplot(y='club',x = "market_value", data=temp_data)


# In[55]:


class DataPreprocessing:
    def __init__(self,data):
        self.data = data
        self.cols_to_be_dropped = ['name','club_id','age_cat','nationality']
        self.cols_to_be_encoded = ['club','position','position_cat','region']
    def addPosCat(self,inputCat):
        if inputCat == 1:
            return('Attackers')
        elif inputCat == 2:
            return('Midfielders')
        elif inputCat == 3:
            return('Defenders')
        else:
            return('Goalkeeper')
    def addRegion(self, inpregion):
        if inpregion == 1:
            return('England')
        elif inpregion == 2:
            return('EU')
        elif inpregion == 3:
            return('Americans')
        else:
            return('Rest of World')
    def columnTypeConversion(self):
        self.data['fpl_sel'] = self.data['fpl_sel'].map(lambda x: str(x)[:-1]).astype('float')
    def logTransformation(self):
        self.data['page_views'] = self.data['page_views'].apply(np.log)
    def dataEncoding(self):
        self.data = pd.get_dummies(self.data, columns = self.cols_to_be_encoded, drop_first = True)  
    def getProcessedData(self):
        self.data = self.data.drop(self.cols_to_be_dropped, inplace = False, axis = 1)
        self.data['position_cat'] = self.data['position_cat'].apply(self.addPosCat)
        self.data['region'] = self.data['region'].apply(self.addRegion)
        self.columnTypeConversion()
        self.dataEncoding()
        self.logTransformation()
        return self.data


# In[56]:


data_obj = DataPreprocessing(fp) 
encoded_data = data_obj.getProcessedData()


# In[57]:


encoded_data.head()


# In[58]:


x=encoded_data.drop('market_value' , axis=1)
y=encoded_data['market_value']


# In[59]:


x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.20)
x_train = x_train.reset_index(drop = True)
x_test = x_test.reset_index(drop = True)
y_train = y_train.reset_index(drop = True)
y_test = y_test.reset_index(drop = True)
print(x_train.shape)
print(x_test.shape)
print(y_train.shape)
print(y_test.shape)


# In[60]:


from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
x_train = scaler.fit_transform(x_train)
x_test = scaler.transform(x_test)


# In[61]:


from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
lin_model = LinearRegression()
lin_model.fit(x_train, y_train)

acc_train = lin_model.score(x_train, y_train)
print("R^2 score of training data - " + str(acc_train))

train_pred = lin_model.predict(x_train) 
mse_train = mean_squared_error(y_train,train_pred)
print("Root Mean Square Error on training data - " + str(mse_train**(0.5)))


# In[ ]:




