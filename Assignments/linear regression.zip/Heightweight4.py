import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt


# Load the data
data = pd.read_csv('HeightVsWeight.csv')


# Split into X and Y
X = data[['Weight']].values
Y = data[['Height']].values

# Split into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)


def train_polynomial_regression(X, Y, degree):
    poly = PolynomialFeatures(degree=degree)
    X_poly = poly.fit_transform(X)

    model = LinearRegression()
    model.fit(X_poly, Y)

    return model, poly

def evaluate(model, X, Y, poly):

    X_poly = poly.transform(X)

    Y_pred = model.predict(X_poly)

    # mean squared error
    mse = mean_squared_error(Y, Y_pred)

    return mse


###training polynomial regression models of degree 1, 2, and 3

models = {}
polys = {}

for degree in range(1, 4):
    model, poly = train_polynomial_regression(X_train, Y_train, degree)
    models[degree] = model
    polys[degree] = poly


##evaluating the models with the mean squared error on the testing set
mses = []
for degree in models:
    mse = evaluate(models[degree], X_test, Y_test, polys[degree])
    mses.append(mse)
    print(f"Degree {degree}: {mse:.2f}")

X_range = np.linspace(X.min(), X.max(), 100).reshape(-1, 1)
fig, ax = plt.subplots()
ax.scatter(X_test, Y_test, color='blue', label='Testing Set')
for degree, model in models.items():
    X_poly = polys[degree].transform(X_range)
    Y_pred = model.predict(X_poly)
    ax.plot(X_range, Y_pred, label=f"Degree {degree}")
ax.legend()
plt.xlabel('Height')
plt.ylabel('Weight')
plt.title('Polynomial Regression Models')
plt.show()



'''
Degree1 : 47.38
Degree2: 5.28
degree3: 1.64


The results show that the mean squared error decreases as the degree of the polynomial increases
'''