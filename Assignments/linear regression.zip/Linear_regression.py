#!/usr/bin/env python
# coding: utf-8

# In[ ]:


##Question1


# In[48]:


import numpy as np
def generate_data(sigma,n,m):
    beta = np.random.randn(m+1)
    X = np.random.randn(n,m)
    X = np.insert(X, 0 , 1 , axis=1)

    #generating noise e
    e = np.random.normal(0,sigma,n)
    Y = np.dot(X,beta) + e
    return X , Y , beta


# In[49]:


X , Y , beta = generate_data(sigma = 1 , n=100 , m=3)
print(X)
print(Y)
print(beta)


# In[50]:


#Question 2 And 3


# In[51]:


def linear_regression(X, Y, k, tau):
    n, m = X.shape
    X = np.insert(X, 0, 1, axis=1)
    beta = np.random.randn(m + 1)
    costs = []

    for _ in range(k):
        predictions = np.dot(X, beta)
        error = predictions - Y
        cost = np.sum(error ** 2) / (2 * n)
        costs.append(cost)

        if len(costs) > 1 and np.abs(costs[-1] - costs[-2]) < tau:
            break

        gradient = np.dot(X.T, error) / n
        beta -= gradient

    return beta, costs

# Assigning values to experiment with
n_values = [50, 100, 200, 1000]
sigma_values = [0.5, 1, 2]
k = 1000
tau = 0.1

for n in n_values:
    for sigma in sigma_values:
        X, Y, true_beta = generate_data(sigma, n, m=3)
        coefficients, costs = linear_regression(X, Y, k, tau)

        print(f"Experiment with n={n}, sigma={sigma}:")
        print("True Beta:", true_beta)
        print("coefficients:", coefficients)
        print("Final cost:", final_cost)
        print()


# The ability of a linear regression function to learn the coefficients Beta is affected by the sample size n and noise level sigma in the data.
# The output from the above code show that as sigma increases and n decreases, the mean squared error between the true coefficients and the estimated coefficients generally increases. Therefore, the accuracy of a linear regression function is influenced by the size of the data set and the level of noise in the data.
