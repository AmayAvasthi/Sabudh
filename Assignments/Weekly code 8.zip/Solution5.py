class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def insertBeforeMiddle(head, value):
    if not head:
        return ListNode(value)

    slow = head
    fast = head
    prev = None

    
    while fast and fast.next:
        prev = slow
        slow = slow.next
        fast = fast.next.next

   
    new_node = ListNode(value)
    if prev:
        prev.next = new_node
    else:
        head = new_node

    new_node.next = slow

    return head

def printList(head):
    while head:
        print(head.val, end="->")
        head = head.next
    print("")


list1 = ListNode(1, ListNode(2, ListNode(3, ListNode(4, ListNode(5)))))
value1 = 9
result1 = insertBeforeMiddle(list1, value1)
print("Test Case 1:")
printList(result1)


list2 = ListNode(11, ListNode(10, ListNode(9, ListNode(7, ListNode(6, ListNode(5, ListNode(4, ListNode(3, ListNode(2, ListNode(1))))))))))
value2 = 8
result2 = insertBeforeMiddle(list2, value2)
print("Test Case 2:")
printList(result2)
