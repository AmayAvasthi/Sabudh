def isMagicNumber(num):
    while num > 9:
        num = sum(map(int, str(num)))
    return num == 1

num1 = 1234
output1 = "Magic Number" if isMagicNumber(num1) else "Not a magic Number"
print(f"Input: {num1}\nOutput: {output1}")


num2 = 12345
output2 = "Magic Number" if isMagicNumber(num2) else "Not a magic Number"
print(f"Input: {num2}\nOutput: {output2}")
