import math

def countWays(N):
    
    ways = math.comb(2 * N, N)
    return ways


N1 = 3
output1 = countWays(N1)
print("Ways for N =", N1, "is", output1)


N2 = 4
output2 = countWays(N2)
print("Ways for N =", N2, "is", output2)
