class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def isSumTree(root):
    if not root or (not root.left and not root.right):
        return True

    left_sum = 0 if not root.left else root.left.val if not root.left.left and not root.left.right else 2 * root.left.val
    right_sum = 0 if not root.right else root.right.val if not root.right.left and not root.right.right else 2 * root.right.val

    return (
        root.val == left_sum + right_sum
        and isSumTree(root.left)
        and isSumTree(root.right)
    )

root1 = TreeNode(26)
root1.left = TreeNode(10)
root1.right = TreeNode(3)
root1.left.left = TreeNode(4)
root1.left.right = TreeNode(6)
root1.right.right = TreeNode(3)

output1 = "The given tree is a SumTree" if isSumTree(root1) else "The given tree is not a SumTree"
print(f"{output1}")

root2 = TreeNode(1)
root2.left = TreeNode(3)
root2.right = TreeNode(6)
root2.left.left = TreeNode(5)
root2.left.right = TreeNode(9)
root2.right.left = TreeNode(8)

output2 = "The given tree is a SumTree" if isSumTree(root2) else "The given tree is not a SumTree"
print(f"{output2}")
