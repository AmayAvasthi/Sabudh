class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def rotateLinkedList(head, k):
    if not head or k == 0:
        return head

    
    length = 1
    tail = head
    while tail.next:
        length += 1
        tail = tail.next

  
    k = k % length
    if k == 0:
        return head

    
    new_tail = head
    for _ in range(length - k - 1):
        new_tail = new_tail.next

    
    new_head = new_tail.next
    new_tail.next = None
    tail.next = head

    return new_head

def printList(head):
    while head:
        print(head.val, end=" -> ")
        head = head.next
    print("None")


list1 = ListNode(10, ListNode(20, ListNode(30, ListNode(40, ListNode(50, ListNode(60))))))
k1 = 4
result1 = rotateLinkedList(list1, k1)
print("Test Case 1:")
printList(result1)


list2 = ListNode(30, ListNode(40, ListNode(50, ListNode(60))))
k2 = 2
result2 = rotateLinkedList(list2, k2)
print("Test Case 2:")
printList(result2)
