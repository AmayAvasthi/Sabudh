def numIslands(mat):
    if not mat or not mat[0]:
        return 0

    rows, cols = len(mat), len(mat[0])
    islands = 0

    def dfs(row, col):
        if 0 <= row < rows and 0 <= col < cols and mat[row][col] == 1:
            mat[row][col] = 2  # Mark as visited
            for i in range(-1, 2):
                for j in range(-1, 2):
                    dfs(row + i, col + j)

    for i in range(rows):
        for j in range(cols):
            if mat[i][j] == 1:
                islands += 1
                dfs(i, j)

    return islands


matrix1 = [
    [1, 1, 0, 0, 0],
    [0, 1, 0, 0, 1],
    [1, 0, 0, 1, 1],
    [0, 0, 0, 0, 0],
    [1, 0, 1, 0, 1]
]
output1 = numIslands(matrix1)
print("Number of islands in Test Case 1:", output1)


matrix2 = [
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
    [0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
]
output2 = numIslands(matrix2)
print("Number of islands in Test Case 2:", output2)
