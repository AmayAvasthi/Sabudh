class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def areIdentical(root1, root2):
    
    if not root1 and not root2:
        return True
    
    
    if not root1 or not root2:
        return False
    
    
    if root1.val != root2.val:
        return False
    
    
    return areIdentical(root1.left, root2.left) and areIdentical(root1.right, root2.right)


root1 = TreeNode(1)
root1.left = TreeNode(2)
root1.right = TreeNode(3)
root1.left.left = TreeNode(4)

root2 = TreeNode(1)
root2.left = TreeNode(2)
root2.right = TreeNode(3)
root2.left.left = TreeNode(4)

output1 = areIdentical(root1, root2)
print(f"{'Both trees are identical' if output1 else 'Trees are not identical'}")


root3 = TreeNode(1)
root3.left = TreeNode(2)
root3.right = TreeNode(3)
root3.left.left = TreeNode(4)

root4 = TreeNode(1)
root4.left = TreeNode(5)
root4.right = TreeNode(3)
root4.left.left = TreeNode(4)

output2 = areIdentical(root3, root4)
print(f"{'Both trees are identical' if output2 else 'Trees are not identical'}")
