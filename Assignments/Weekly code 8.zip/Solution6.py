class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def deleteLastOccurrence(head, key):
    if not head:
        return None

    prev = None
    last_occurrence = None
    current = head

    while current:
        if current.val == key:
            last_occurrence = current
        prev = current
        current = current.next

    if last_occurrence:
        if prev:
            prev.next = last_occurrence.next
        else:
            head = last_occurrence.next

    return head

def printList(head):
    while head:
        print(head.val, end=" --> ")
        head = head.next
    print("NULL")


list1 = ListNode(1, ListNode(2, ListNode(3, ListNode(4, ListNode(5, ListNode(4, ListNode(4)))))))
key1 = 4
result1 = deleteLastOccurrence(list1, key1)
print("Test Case 1:")
printList(result1)


list2 = ListNode(11, ListNode(32, ListNode(123, ListNode(344, ListNode(445, ListNode(484, ListNode(534)))))))
key2 = 445
result2 = deleteLastOccurrence(list2, key2)
print("Test Case 2:")
printList(result2)
