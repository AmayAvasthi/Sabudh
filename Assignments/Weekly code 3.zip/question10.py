{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "542ab7e5-935c-4fc9-ba9d-9add1758e294",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "7\n",
      "6\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, val=0, next=None):\n",
    "        self.val = val\n",
    "        self.next = next\n",
    "\n",
    "def maximizeTwinSum(head):\n",
    "    length = 0\n",
    "    current = head\n",
    "    while current:\n",
    "        length += 1\n",
    "        current = current.next\n",
    "    \n",
    "    skip_count = length // 2\n",
    "    \n",
    "    front_ptr = head\n",
    "    back_ptr = head\n",
    "    \n",
    "    for _ in range(skip_count):\n",
    "        back_ptr = back_ptr.next\n",
    "    \n",
    "    max_sum = float('-inf')  \n",
    "    \n",
    "    while back_ptr:\n",
    "        max_sum = max(max_sum, front_ptr.val + back_ptr.val)\n",
    "        front_ptr = front_ptr.next\n",
    "        back_ptr = back_ptr.next\n",
    "    \n",
    "    return max_sum\n",
    "\n",
    "lis1 = ListNode(5)\n",
    "lis1.next = ListNode(4)\n",
    "lis1.next.next = ListNode(2)\n",
    "lis1.next.next.next = ListNode(1)\n",
    "\n",
    "lis2 = ListNode(4)\n",
    "lis2.next = ListNode(2)\n",
    "lis2.next.next = ListNode(2)\n",
    "lis2.next.next.next = ListNode(3)\n",
    "\n",
    "print(maximizeTwinSum(lis1)) \n",
    "print(maximizeTwinSum(lis2)) "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "680a5ca0-6d46-4824-8fa1-8a5ac5433bd1",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
