{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 15,
   "id": "f88b8567-c72a-4221-93f1-4b8d55e4ce12",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "The middle element is 4\n",
      "The middle element is 3\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def find_middle(head):\n",
    "    if not head:\n",
    "        return None\n",
    "\n",
    "    slow = head\n",
    "    fast = head\n",
    "    prev_slow = None\n",
    "\n",
    "    while fast is not None and fast.next is not None:\n",
    "        fast = fast.next.next\n",
    "        prev_slow = slow\n",
    "        slow = slow.next\n",
    "\n",
    "    if prev_slow:\n",
    "        print(\"The middle element is\", slow.val)\n",
    "    else:\n",
    "        print(\"The middle element is\", slow.val)\n",
    "\n",
    "\n",
    "head1 = ListNode(2)\n",
    "head1.next = ListNode(3)\n",
    "head1.next.next = ListNode(4)\n",
    "head1.next.next.next = ListNode(5)\n",
    "find_middle(head1)\n",
    "\n",
    "head2 = ListNode(1)\n",
    "head2.next = ListNode(2)\n",
    "head2.next.next = ListNode(3)\n",
    "head2.next.next.next = ListNode(4)\n",
    "head2.next.next.next.next = ListNode(5)\n",
    "find_middle(head2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2db7d57b-816a-44a0-94d4-c13ab571a94c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
