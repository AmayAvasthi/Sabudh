{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 19,
   "id": "f88b8567-c72a-4221-93f1-4b8d55e4ce12",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input: 1999\n",
      "Output: 2000\n",
      "Input: 3453\n",
      "Output: 3454\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def reverse_linked_list(head):\n",
    "    prev = None\n",
    "    current = head\n",
    "\n",
    "    while current is not None:\n",
    "        next_node = current.next\n",
    "        current.next = prev\n",
    "        prev = current\n",
    "        current = next_node\n",
    "\n",
    "    return prev\n",
    "\n",
    "def add_one_to_linked_list(head):\n",
    "    # Reverse the linked list\n",
    "    head = reverse_linked_list(head)\n",
    "    current = head\n",
    "    carry = 1\n",
    "\n",
    "    while current is not None:\n",
    "        total = current.val + carry\n",
    "        carry = total // 10\n",
    "        current.val = total % 10\n",
    "        if carry == 0:\n",
    "            break\n",
    "        if current.next is None:\n",
    "            current.next = ListNode(0)\n",
    "        current = current.next\n",
    "\n",
    "    # Reverse the linked list again to get the final result\n",
    "    head = reverse_linked_list(head)\n",
    "    return head\n",
    "\n",
    "# Helper function to convert a number to a linked list\n",
    "def number_to_linked_list(number):\n",
    "    dummy = ListNode(None)\n",
    "    current = dummy\n",
    "\n",
    "    for digit in str(number):\n",
    "        current.next = ListNode(int(digit))\n",
    "        current = current.next\n",
    "\n",
    "    return dummy.next\n",
    "\n",
    "# Helper function to convert a linked list to a number\n",
    "def linked_list_to_number(head):\n",
    "    current = head\n",
    "    number_str = \"\"\n",
    "\n",
    "    while current:\n",
    "        number_str += str(current.val)\n",
    "        current = current.next\n",
    "\n",
    "    return int(number_str)\n",
    "\n",
    "# Test cases\n",
    "# Test Case 1: Input: 1999, Output: 2000\n",
    "input_num1 = 1999\n",
    "head1 = number_to_linked_list(input_num1)\n",
    "result_head1 = add_one_to_linked_list(head1)\n",
    "output_num1 = linked_list_to_number(result_head1)\n",
    "print(\"Input:\", input_num1)\n",
    "print(\"Output:\", output_num1)\n",
    "\n",
    "# Test Case 2: Input: 3453, Output: 3454\n",
    "input_num2 = 3453\n",
    "head2 = number_to_linked_list(input_num2)\n",
    "result_head2 = add_one_to_linked_list(head2)\n",
    "output_num2 = linked_list_to_number(result_head2)\n",
    "print(\"Input:\", input_num2)\n",
    "print(\"Output:\", output_num2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2db7d57b-816a-44a0-94d4-c13ab571a94c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
