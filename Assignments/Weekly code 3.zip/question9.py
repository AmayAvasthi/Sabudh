{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "e01da3fa-cd6e-411f-bab3-3cbd045ea7f4",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input List: [2, 3, 4, 5]\n",
      "Value to Insert: 1\n",
      "Output List: [1, 2, 3, 4, 5]\n",
      "Input List: [3, 2, 5, 7, 1, 2]\n",
      "Value to Insert: 9\n",
      "Output List: [9, 3, 2, 5, 7, 1, 2]\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def insert_at_beginning(head, value):\n",
    "    new_node = ListNode(value)\n",
    "    new_node.next = head \n",
    "    return new_node      \n",
    "\n",
    "# Helper function to convert a list to a linked list\n",
    "def list_to_linked_list(lst):\n",
    "    dummy = ListNode(None)\n",
    "    current = dummy\n",
    "\n",
    "    for val in lst:\n",
    "        current.next = ListNode(val)\n",
    "        current = current.next\n",
    "\n",
    "    return dummy.next\n",
    "\n",
    "def linked_list_to_list(head):\n",
    "    result = []\n",
    "    current = head\n",
    "    while current:\n",
    "        result.append(current.val)\n",
    "        current = current.next\n",
    "    return result\n",
    "\n",
    "\n",
    "input_list1 = [2, 3, 4, 5]\n",
    "value1 = 1\n",
    "head1 = list_to_linked_list(input_list1)\n",
    "result_head1 = insert_at_beginning(head1, value1)\n",
    "result_list1 = linked_list_to_list(result_head1)\n",
    "print(\"Input List:\", input_list1)\n",
    "print(\"Value to Insert:\", value1)\n",
    "print(\"Output List:\", result_list1)\n",
    "\n",
    "input_list2 = [3, 2, 5, 7, 1, 2]\n",
    "value2 = 9\n",
    "head2 = list_to_linked_list(input_list2)\n",
    "result_head2 = insert_at_beginning(head2, value2)\n",
    "result_list2 = linked_list_to_list(result_head2)\n",
    "print(\"Input List:\", input_list2)\n",
    "print(\"Value to Insert:\", value2)\n",
    "print(\"Output List:\", result_list2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "5bf95ab8-50c2-4363-b2f4-4a531d1d1097",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
