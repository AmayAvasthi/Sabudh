{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "f88b8567-c72a-4221-93f1-4b8d55e4ce12",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input: \n",
      "1 2 3 4 5 \n",
      "Output: \n",
      "1 2 4 5 \n",
      "Input: \n",
      "2 4 6 7 5 1 \n",
      "Output: \n",
      "2 4 6 5 1 \n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def delete_middle(head):\n",
    "    if not head or not head.next:\n",
    "        return None  \n",
    "\n",
    "    slow = head\n",
    "    fast = head\n",
    "    prev_slow = None\n",
    "\n",
    "    while fast is not None and fast.next is not None:\n",
    "        fast = fast.next.next\n",
    "        prev_slow = slow\n",
    "        slow = slow.next\n",
    "\n",
    "    if prev_slow:\n",
    "        prev_slow.next = slow.next\n",
    "    else:\n",
    "        head = head.next\n",
    "\n",
    "    return head\n",
    "\n",
    "def print_linked_list(head):\n",
    "    current = head\n",
    "    while current:\n",
    "        print(current.val, end=\" \")\n",
    "        current = current.next\n",
    "    print()\n",
    "\n",
    "\n",
    "head1 = ListNode(1)\n",
    "head1.next = ListNode(2)\n",
    "head1.next.next = ListNode(3)\n",
    "head1.next.next.next = ListNode(4)\n",
    "head1.next.next.next.next = ListNode(5)\n",
    "print(\"Input: \")\n",
    "print_linked_list(head1)\n",
    "head1 = delete_middle(head1)\n",
    "print(\"Output: \")\n",
    "print_linked_list(head1)\n",
    "\n",
    "head2 = ListNode(2)\n",
    "head2.next = ListNode(4)\n",
    "head2.next.next = ListNode(6)\n",
    "head2.next.next.next = ListNode(7)\n",
    "head2.next.next.next.next = ListNode(5)\n",
    "head2.next.next.next.next.next = ListNode(1)\n",
    "print(\"Input: \")\n",
    "print_linked_list(head2)\n",
    "head2 = delete_middle(head2)\n",
    "print(\"Output: \")\n",
    "print_linked_list(head2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2db7d57b-816a-44a0-94d4-c13ab571a94c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
