{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "412b7813-4cd8-4e28-8943-2250468c78c3",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input: [2, 4, 6, 8, 33, 67]\n",
      "Output: 33\n",
      "Input: [1, 2, 3, 4, 5]\n",
      "Output: 4\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def find_second_last_element(head):\n",
    "    if not head or not head.next:\n",
    "        return None  \n",
    "    current = head\n",
    "    prev = None\n",
    "\n",
    "    while current.next is not None:\n",
    "        prev = current\n",
    "        current = current.next\n",
    "\n",
    "    return prev.val\n",
    "\n",
    "def list_to_linked_list(lst):\n",
    "    dummy = ListNode(None)\n",
    "    current = dummy\n",
    "\n",
    "    for val in lst:\n",
    "        current.next = ListNode(val)\n",
    "        current = current.next\n",
    "\n",
    "    return dummy.next\n",
    "\n",
    "\n",
    "input_list1 = [2, 4, 6, 8, 33, 67]\n",
    "head1 = list_to_linked_list(input_list1)\n",
    "result1 = find_second_last_element(head1)\n",
    "print(\"Input:\", input_list1)\n",
    "print(\"Output:\", result1)\n",
    "\n",
    "input_list2 = [1, 2, 3, 4, 5]\n",
    "head2 = list_to_linked_list(input_list2)\n",
    "result2 = find_second_last_element(head2)\n",
    "print(\"Input:\", input_list2)\n",
    "print(\"Output:\", result2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "1d8264a0-99d9-4a10-8cbb-1b096193a9d0",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
