{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "e971846a-a796-4a78-90ab-23803c1fa862",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input: restart\n",
      "Output: resta$t\n",
      "Input: tatras\n",
      "Output: ta$ras\n"
     ]
    }
   ],
   "source": [
    "def replace_first_char_occurrences(input_str):\n",
    "    if len(input_str) < 2:\n",
    "        return input_str\n",
    "\n",
    "    first_char = input_str[0]\n",
    "    modified_str = first_char  \n",
    "    for char in input_str[1:]:\n",
    "        if char == first_char:\n",
    "            modified_str += '$'\n",
    "        else:\n",
    "            modified_str += char\n",
    "\n",
    "    return modified_str\n",
    "\n",
    "\n",
    "input_str1 = \"restart\"\n",
    "result1 = replace_first_char_occurrences(input_str1)\n",
    "print(\"Input:\", input_str1)\n",
    "print(\"Output:\", result1)\n",
    "\n",
    "input_str2 = \"tatras\"\n",
    "result2 = replace_first_char_occurrences(input_str2)\n",
    "print(\"Input:\", input_str2)\n",
    "print(\"Output:\", result2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "70403ae5-f373-4d6d-bff1-943dd67f8a6d",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
