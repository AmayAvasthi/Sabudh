{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 13,
   "id": "f88b8567-c72a-4221-93f1-4b8d55e4ce12",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input: \n",
      "1->2->3->4->None\n",
      "Output: \n",
      "4->3->2->1->None\n",
      "Input: \n",
      "1->2->3->4->5->None\n",
      "Output: \n",
      "5->4->3->2->1->None\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def reverse_linked_list(head):\n",
    "    prev = None\n",
    "    current = head\n",
    "\n",
    "    while current is not None:\n",
    "        next_node = current.next  # Save the next node\n",
    "        current.next = prev      # Change the next of the current node to the previous node\n",
    "        prev = current           # Move prev to the current node\n",
    "        current = next_node      # Move current to the next node\n",
    "\n",
    "    return prev \n",
    "def print_linked_list(head):\n",
    "    current = head\n",
    "    while current:\n",
    "        print(current.val, end=\"->\")\n",
    "        current = current.next\n",
    "    print(\"None\")\n",
    "\n",
    "\n",
    "head1 = ListNode(1)\n",
    "head1.next = ListNode(2)\n",
    "head1.next.next = ListNode(3)\n",
    "head1.next.next.next = ListNode(4)\n",
    "print(\"Input: \")\n",
    "print_linked_list(head1)\n",
    "head1 = reverse_linked_list(head1)\n",
    "print(\"Output: \")\n",
    "print_linked_list(head1)\n",
    "\n",
    "head2 = ListNode(1)\n",
    "head2.next = ListNode(2)\n",
    "head2.next.next = ListNode(3)\n",
    "head2.next.next.next = ListNode(4)\n",
    "head2.next.next.next.next = ListNode(5)\n",
    "print(\"Input: \")\n",
    "print_linked_list(head2)\n",
    "head2 = reverse_linked_list(head2)\n",
    "print(\"Output: \")\n",
    "print_linked_list(head2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2db7d57b-816a-44a0-94d4-c13ab571a94c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
