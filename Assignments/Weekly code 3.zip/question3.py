{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "f88b8567-c72a-4221-93f1-4b8d55e4ce12",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input: \n",
      "11->11->11->13->13->20->None\n",
      "Output: \n",
      "11->13->20->None\n",
      "Input: \n",
      "10->15->15->15->20->20->20->23->25->25->None\n",
      "Output: \n",
      "10->15->20->23->25->None\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def remove_duplicates(head):\n",
    "    if not head or not head.next:\n",
    "        return head\n",
    "\n",
    "    current = head\n",
    "    while current.next:\n",
    "        if current.val == current.next.val:\n",
    "            current.next = current.next.next\n",
    "        else:\n",
    "            current = current.next\n",
    "\n",
    "    return head\n",
    "\n",
    "def print_linked_list(head):\n",
    "    current = head\n",
    "    while current:\n",
    "        print(current.val, end=\"->\")\n",
    "        current = current.next\n",
    "    print(\"None\")\n",
    "\n",
    "\n",
    "head1 = ListNode(11)\n",
    "head1.next = ListNode(11)\n",
    "head1.next.next = ListNode(11)\n",
    "head1.next.next.next = ListNode(13)\n",
    "head1.next.next.next.next = ListNode(13)\n",
    "head1.next.next.next.next.next = ListNode(20)\n",
    "print(\"Input: \")\n",
    "print_linked_list(head1)\n",
    "head1 = remove_duplicates(head1)\n",
    "print(\"Output: \")\n",
    "print_linked_list(head1)\n",
    "\n",
    "head2 = ListNode(10)\n",
    "head2.next = ListNode(15)\n",
    "head2.next.next = ListNode(15)\n",
    "head2.next.next.next = ListNode(15)\n",
    "head2.next.next.next.next = ListNode(20)\n",
    "head2.next.next.next.next.next = ListNode(20)\n",
    "head2.next.next.next.next.next.next = ListNode(20)\n",
    "head2.next.next.next.next.next.next.next = ListNode(23)\n",
    "head2.next.next.next.next.next.next.next.next = ListNode(25)\n",
    "head2.next.next.next.next.next.next.next.next.next = ListNode(25)\n",
    "print(\"Input: \")\n",
    "print_linked_list(head2)\n",
    "head2 = remove_duplicates(head2)\n",
    "print(\"Output: \")\n",
    "print_linked_list(head2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2db7d57b-816a-44a0-94d4-c13ab571a94c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
