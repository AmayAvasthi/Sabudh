{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 17,
   "id": "f88b8567-c72a-4221-93f1-4b8d55e4ce12",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Input: 563 + 842\n",
      "Output: 316\n",
      "Input: 75946 + 84\n",
      "Output: 50056\n"
     ]
    }
   ],
   "source": [
    "class ListNode:\n",
    "    def __init__(self, value):\n",
    "        self.val = value\n",
    "        self.next = None\n",
    "\n",
    "def add_two_numbers(l1, l2):\n",
    "    dummy = ListNode(0)\n",
    "    current = dummy\n",
    "    carry = 0\n",
    "\n",
    "    while l1 or l2:\n",
    "        x = l1.val if l1 else 0\n",
    "        y = l2.val if l2 else 0\n",
    "        total = x + y + carry\n",
    "\n",
    "        carry = total // 10\n",
    "        current.next = ListNode(total % 10)\n",
    "\n",
    "        if l1:\n",
    "            l1 = l1.next\n",
    "        if l2:\n",
    "            l2 = l2.next\n",
    "\n",
    "        current = current.next\n",
    "\n",
    "    if carry:\n",
    "        current.next = ListNode(carry)\n",
    "\n",
    "    return dummy.next\n",
    "\n",
    "def number_to_linked_list(number):\n",
    "    dummy = ListNode(None)\n",
    "    current = dummy\n",
    "\n",
    "    for digit in str(number):\n",
    "        current.next = ListNode(int(digit))\n",
    "        current = current.next\n",
    "\n",
    "    return dummy.next\n",
    "\n",
    "def linked_list_to_number(head):\n",
    "    current = head\n",
    "    number_str = \"\"\n",
    "\n",
    "    while current:\n",
    "        number_str += str(current.val)\n",
    "        current = current.next\n",
    "\n",
    "    return int(number_str)\n",
    "\n",
    "\n",
    "input_num1 = 563\n",
    "input_num2 = 842\n",
    "head1 = number_to_linked_list(input_num1)\n",
    "head2 = number_to_linked_list(input_num2)\n",
    "result_head1 = add_two_numbers(head1, head2)\n",
    "output_num1 = linked_list_to_number(result_head1)\n",
    "print(\"Input:\", input_num1, \"+\", input_num2)\n",
    "print(\"Output:\", output_num1)\n",
    "\n",
    "input_num3 = 75946\n",
    "input_num4 = 84\n",
    "head3 = number_to_linked_list(input_num3)\n",
    "head4 = number_to_linked_list(input_num4)\n",
    "result_head2 = add_two_numbers(head3, head4)\n",
    "output_num2 = linked_list_to_number(result_head2)\n",
    "print(\"Input:\", input_num3, \"+\", input_num4)\n",
    "print(\"Output:\", output_num2)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2db7d57b-816a-44a0-94d4-c13ab571a94c",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.12"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
