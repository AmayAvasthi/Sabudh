import numpy as np 

def generate_logistic_regression(X, Y, k, tau, learning_rate):
    n, m=X.shape 
    
    beta= np.random.rand(m)
    
    def sigmoid(z):
        return 1/(1+ np.exp(-z))
    
    def compute_cost(X,Y, beta):
        linear_combination= np.dot(X, beta)
        probabilities= sigmoid(linear_combination)
        
        cost = -np.mean(Y * np.log(probabilities) + (1 - Y) * np.log(1 - probabilities))
        return cost
    
    prev_cost= compute_cost(X, Y, beta)
    history_cost= []
    
    for i in range(k):
        linear_combination= np.dot(X, beta)
        probabilities= sigmoid(linear_combination)
        gradient=np.dot(X.T, probabilities-Y)/n
        beta -= learning_rate * gradient
        current_cost= compute_cost(X, Y, beta)
        history_cost.append(current_cost)
        if np.all(abs(current_cost - prev_cost) < tau):
            break
        
        prev_cost=current_cost
        
        
    return beta , current_cost  
        
        

n=1000 
m=5 
X= np.random.rand(n, m+1)
Y=np.random.randint(2, size=n)

k=1000
tau=1e-6
learning_rate=0.01

coefficients, final_cost= generate_logistic_regression(X, Y, k, tau,learning_rate)

print(f"beta:{coefficients}, current_cost:{final_cost}")