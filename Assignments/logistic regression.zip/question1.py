import numpy as np 

def generate_regression(theta, n, m):
    beta=np.random.rand(m+1) #generating random coefficient for the linear relationship betweeen X and Y
    
    X=np.random.rand(n,m) #generating n X m random independent variable values
    
    X=np.concatenate((np.ones((n,1)), X),axis=1)
    
    #calculating the linear relationship between X and beta
    linear_combination= np.dot(X, beta)
    
    probabilities= 1/(1+np.exp(-linear_combination))
    
    Y= (probabilities>0.5).astype(int)
    
    noise=np.random.binomial(1, theta, n)
    Y=(Y+noise)%2
    
    return X,Y, beta

theta=0.2
n=1000
m=5 


X, Y, beta= generate_regression(theta, n, m)

print(f"X:{X} , Y:{Y}, beta:{beta}")