import numpy as np 

def generate_logistic_regression(X, Y, k, tau, learning_rate, Lambda1, Lambda2):
    n, m=X.shape 
    
    beta= np.random.rand(m)
    
    def sigmoid(z):
        return 1/(1+ np.exp(-z))
    
    def compute_cost(X,Y, beta, Lambda1, Lambda2):
        linear_combination= np.dot(X, beta)
        probabilities= sigmoid(linear_combination)
        
        L1_regularization= Lambda1* np.sum(np.abs(beta))
        L2_regularization= Lambda2* np.sum((beta)**2)
        
        regularized_cost = -np.mean(Y * np.log(probabilities) + (1 - Y) * np.log(1 - probabilities)) + L1_regularization + L2_regularization
        return regularized_cost
    
    prev_cost= compute_cost(X, Y, beta, Lambda1, Lambda2)
    history_cost= []
    
    for i in range(k):
        linear_combination= np.dot(X, beta)
        probabilities= sigmoid(linear_combination)
        gradient=(np.dot(X.T, probabilities-Y)+ Lambda1* np.sign(beta) + Lambda2*beta)/n
        beta -= learning_rate * gradient
        current_cost= compute_cost(X, Y, beta, Lambda1, Lambda2)
        history_cost.append(current_cost)
        if np.all(abs(current_cost - prev_cost) < tau):
            break
        
        prev_cost=current_cost
        
        
    return beta , current_cost  
        
        

n=1000 
m=5 
X= np.random.rand(n, m+1)
Y=np.random.randint(2, size=n)

k=1000
tau=1e-6
learning_rate=0.01

lambda1_values=[0.1,0.01,1.0]
lambda2_values=[0.1,0.01,1.0]

for Lambda1 in lambda1_values:
    for Lambda2 in lambda2_values:
        coefficients, final_cost = generate_logistic_regression(X, Y, k, tau, learning_rate, Lambda1, Lambda2)
        print(f"Lambda1: {Lambda1}, Lambda2: {Lambda2}")
        print(f"Beta: {coefficients}")
        print(f"Final Cost: {final_cost}")