import numpy as np

class BaseRegression:
    def __init__(self, X, Y, k_iterations, tau):
        self.X = X
        self.Y = Y
        self.k_iterations = k_iterations
        self.tau = tau

    def compute_cost(self, X, Y, beta):
        raise NotImplementedError("Subclasses must implement compute_cost method")

    def gradient_descent(self):
        n, m = self.X.shape
        X = np.insert(self.X, 0, 1, axis=1)
        beta = np.random.rand(m + 1)

        prev_cost = self.compute_cost(X, self.Y, beta)

        for i in range(self.k_iterations):
            predictions_y = np.dot(X, beta)
            squared_error = predictions_y - self.Y
            gradient = np.dot(X.T, squared_error) / n
            beta -= gradient

            current_cost = self.compute_cost(X, self.Y, beta)
            cost_change = prev_cost - current_cost
            prev_cost = current_cost

            if cost_change <= self.tau:
                break

        return beta, current_cost

class LinearRegression(BaseRegression):
    def compute_cost(self, X, Y, beta):
        predicted_y = np.dot(X, beta)
        squared_error = (predicted_y - Y) ** 2
        cost = np.sum(squared_error) / (2 * len(Y))
        return cost

class LogisticRegression(BaseRegression):
    def __init__(self, X, Y, k_iterations, tau, learning_rate, lambda_l1, lambda_l2):
        super().__init__(X, Y, k_iterations, tau)
        self.learning_rate = learning_rate
        self.lambda_l1 = lambda_l1
        self.lambda_l2 = lambda_l2

    def sigmoid(self, z):
        return 1 / (1 + np.exp(-z))

    def compute_cost(self, X, Y, beta):
        linear_combination = np.dot(X, beta)
        probabilities = self.sigmoid(linear_combination)

        L1_regularization = self.lambda_l1 * np.sum(np.abs(beta))
        L2_regularization = self.lambda_l2 * np.sum(beta ** 2)

        regularized_cost = -np.mean(Y * np.log(probabilities) + (1 - Y) * np.log(1 - probabilities)) + L1_regularization + L2_regularization

        return regularized_cost

# Usage

n = 100
m = 2
X_linear = np.random.rand(n, m)
Y_linear = 2 * X_linear[:, 0] + 3 * X_linear[:, 1] + np.random.normal(0, 0.1, n)

n_logistic = 1000
m_logistic = 5
X_logistic = np.random.rand(n_logistic, m_logistic + 1)
Y_logistic = np.random.randint(2, size=n_logistic)

K_iterations = 1000
tau = 1e-6
learning_rate = 0.01

# Linear Regression
linear_reg = LinearRegression(X_linear, Y_linear, K_iterations, tau)
coefficients, final_cost = linear_reg.gradient_descent()
print("Linear Regression - Learned Coefficients:", coefficients)
print("Linear Regression - Final Cost:", final_cost)

# Logistic Regression
lambda_l1 = 0.1
lambda_l2 = 0.01
logistic_reg = LogisticRegression(X_logistic, Y_logistic, K_iterations, tau, learning_rate, lambda_l1, lambda_l2)
coefficients, final_cost = logistic_reg.gradient_descent()
print("Logistic Regression - Learned Coefficients:", coefficients)
print("Logistic Regression - Final Cost:", final_cost)
